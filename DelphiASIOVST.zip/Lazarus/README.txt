Package CGILazIDE

This package is a designtime package for the Lazarus IDE.
It adds a new project type and a new unit type to the IDE.

New Project Type:
  CGI Application - A Free Pascal program for CGI
                 using TCgiApplication for the main source (normally hidden,
                 just like the .lpr file for a normal Application).

New Unit Type:
  CGI Module - A unit with a TCGIDatamodule.




