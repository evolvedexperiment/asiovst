
# hash value = 247901844
dvstmodule.sresnotfound='Resource %s not found'

